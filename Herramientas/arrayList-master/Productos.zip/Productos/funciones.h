int recibeInt(char mensaje[]);
int recibeIntRango(char mensaje[], char mensajeError [], int limiteInf, int limiteSup);
float recibeFloat(char mensaje[]);
char recibeChar(char mensaje[]);

int esNumerico(char str[]) ;
int esTelefono(char str[]);
int esAlfaNumerico(char str[]);
int esSoloLetras(char str[]);
int esNumericoFlotante(char str[]);

void recibeString(char mensaje[],char input[]);
int recibeStringLetras(char mensaje[],char input[]);
void recibeStringLetrasValido(char mensaje[], char mensajeError[], char input []);
int recibeStringNumeros(char mensaje[],char input[]);
int recibeStringNumerosFlotantes(char mensaje[],char input[]);
int recibeStringANumeroRango(char mensaje[], char mensajeError[], int limiteInf, int limiteSup);
float recibeStringANumeroRangoFloat(char mensaje[], char mensajeError[], float limiteInf, float limiteSup);

